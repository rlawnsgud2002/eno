# 아산시 GPS 체류 후보 분석 · Excel 통합 보고서

> **독립 GPS 분석 프로그램**입니다. 이노 관제·배차 프로그램과 별개이며, 웹 대시보드를 실행하지 않습니다.
> Windows 설치·키 설정·샘플·전체 데이터 실행 명령은 [Windows 실행 순서](WINDOWS_실행순서.md)를 참고하세요.

웹 대시보드가 없는 독립 Python 프로그램입니다. 기본 범위는 2026-04-01~08-31, 3~14·28~36호차입니다. GPS로 검출한 것은 **체류/방문 후보**이며 실제 승하차·시설 이용이나 정차와 정체를 완전히 구별한 결과가 아닙니다. 이 구분은 보고서에도 표시됩니다.

## PowerShell 직접 설치·실행 (스마트 앱 컨트롤 유지)


이 절차는 Windows 스마트 앱 컨트롤을 켠 상태에서 사용할 수 있는 표준 Python 실행 방법입니다. 배치 파일이나 PowerShell 스크립트 파일을 실행하지 않고, 열린 PowerShell 창에 명령을 한 줄씩 입력합니다. 보호 기능이나 실행 정책은 변경하지 않습니다. GPS 프로그램을 독립 실행 EXE로 패키징하지 않았으며, 아래 `python.exe`는 설치한 Python 인터프리터입니다.

**실행 가능 여부는 실제로 차단된 파일에 달려 있습니다.** Python 자체 또는 의존성의 DLL/PYD까지 Windows가 차단하면 이 절차로 실행이 보장되지는 않습니다. 이때 차단을 무시하거나 파일 이름을 바꾸지 말고, 차단 알림의 파일명과 공식 배포본의 서명·출처를 확인하세요. Microsoft의 [Smart App Control 안내](https://support.microsoft.com/en-us/windows/security/threat-malware-protection/smart-app-control-frequently-asked-questions)를 참고하세요. 이번 검증 환경은 Linux이며 Windows 스마트 앱 컨트롤을 켠 PC에서 실기 검증한 것은 아닙니다.

### 1. Python과 작업 폴더 준비

- **Python 3.12 64비트**가 필요합니다. 32비트나 다른 버전으로 설치된 환경은 이번 검증 대상이 아닙니다.
- Microsoft Store의 Python Software Foundation 제공 Python 3.12 또는 [python.org의 공식 Windows 설치본](https://www.python.org/downloads/windows/)을 사용하세요. Python 자체 설치는 기존 `install.bat`이 자동 수행하지 않습니다.
- ZIP 전체를 압축 해제하세요. 기존 `이노베이스_GPS_프로그램.zip`은 그대로 제공하며, 문서를 추가한 배포본은 `이노베이스_GPS_프로그램_PowerShell안내.zip`입니다. 두 ZIP의 GPS 실행 소스·배치 파일·자동 테스트는 같습니다.
- `requirements.txt`, `config.json`, `gps_analyzer` 폴더가 함께 보이는 **압축 해제 폴더**에서 PowerShell을 여세요. GitHub의 Code → Download ZIP으로 받았다면 `gps-analyzer` 하위 폴더가 프로그램 폴더입니다.
- 폴더를 이동할 때는 실제 경로를 따옴표로 감싸세요. 예: `Set-Location -LiteralPath 'C:\GPS\이노베이스_GPS_프로그램'`. 원본 GPS는 별도 폴더에 보관합니다.

현재 폴더와 Python을 확인합니다.

```powershell
Get-Location
Test-Path -LiteralPath '.\requirements.txt'
py -3.12 --version
py -3.12 -c "import sys, struct; print(sys.executable); print('bits:', struct.calcsize('P') * 8); assert sys.version_info[:2] == (3, 12) and struct.calcsize('P') == 8, 'Python 3.12 64-bit required'"
```

`Test-Path`는 `True`, 버전은 `Python 3.12.x`, `bits`는 `64`여야 합니다. `py` 명령이 없고 `python`만 있다면 다음 명령으로 확인합니다.

```powershell
python --version
python -c "import sys, struct; print(sys.executable); print('bits:', struct.calcsize('P') * 8); assert sys.version_info[:2] == (3, 12) and struct.calcsize('P') == 8, 'Python 3.12 64-bit required'"
```

어느 경우든 오류·보안 차단이 보이면 다음 단계로 계속 진행하지 마세요. Python이 없으면 공식 설치를 완료하고 새 PowerShell 창을 여세요.

### 2. 가상환경과 의존성 설치

`py -3.12` 확인에 성공했다면 다음을 실행합니다.

```powershell
py -3.12 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Virtual environment creation failed. Stop here.' }
```

`py` 대신 위에서 확인한 `python`을 사용하는 경우에만, 위 두 줄 대신 다음을 실행합니다.

```powershell
python -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Virtual environment creation failed. Stop here.' }
```

이후 명령은 두 경우 모두 동일합니다. PowerShell의 `&`를 포함해 입력하세요.

```powershell
& '.\.venv\Scripts\python.exe' -m pip install -r '.\requirements.txt'
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Stop here.' }
& '.\.venv\Scripts\python.exe' -c "import duckdb, openpyxl, xlsxwriter, shapely, requests, dotenv; print('Dependency check OK')"
if ($LASTEXITCODE -ne 0) { throw 'Dependency import failed. Stop here.' }
```

필요한 패키지는 DuckDB, openpyxl, XlsxWriter, Shapely, requests, python-dotenv이며 버전 범위는 `requirements.txt`에 있습니다. 가상환경 활성화 스크립트는 실행하지 않아도 됩니다. 프로젝트 폴더 안의 Python을 직접 지정하므로 관리자 권한이나 전역 패키지 설치도 필요하지 않습니다. 설치에는 패키지 다운로드를 위한 인터넷 연결이 필요합니다.

### 3. API 키 설정 — 키 없이 먼저 분석해도 됨

`.env`가 없을 때만 예제 파일을 복사합니다. 기존 키는 덮어쓰지 않습니다.

```powershell
if (-not (Test-Path -LiteralPath '.\.env')) { Copy-Item -LiteralPath '.\.env.example' -Destination '.\.env' }
notepad.exe '.\.env'
```

메모장에서 아래 이름에 본인이 발급받은 값만 입력하고 저장하세요. 키를 PowerShell 명령줄이나 GitHub에 입력하지 않습니다.

```dotenv
KAKAO_REST_API_KEY=
DATA_GO_KR_SERVICE_KEY=
VWORLD_API_KEY=
VWORLD_SERVICE_URL=http://localhost:8000
```

보유하지 않은 키는 빈 값으로 두면 됩니다. 기본 `config.json`의 `api.enabled`는 `false`입니다. 이 상태에서도 GPS 정제·체류 후보 탐지·7개 시트 Excel은 생성되며 장소는 미확인으로 남을 수 있습니다. 실제 `.env`와 GPS 원본·결과 보고서·캐시는 배포 ZIP이나 GitHub에 넣지 않습니다.

### 4. 샘플 하나로 실행

예를 들어 `D:\GPS샘플` 폴더에는 본인이 가진 `ASAN_29_2026_06_11.xlsx` 하나만 넣으세요. 아래 원본 경로는 실제 PC의 폴더로 바꾸세요. 프로그램은 원본을 읽기만 합니다.

```powershell
& '.\.venv\Scripts\python.exe' -m gps_analyzer --input 'D:\GPS샘플' --output '.\output' --work '.\work_data' --config '.\config.json'
if ($LASTEXITCODE -ne 0) { throw 'Sample analysis failed. Check work_data\analysis.log.' }
```

샘플 테스트를 포함한 기존 자동 테스트63개를 실행하려면:

```powershell
$env:GPS_SAMPLE_FILE = 'D:\GPS샘플\ASAN_29_2026_06_11.xlsx'
& '.\.venv\Scripts\python.exe' -m unittest discover -s '.\tests' -v
```

`GPS_SAMPLE_FILE`이 실제 파일을 가리키지 않으면 실제 샘플 테스트4개는 건너뜁니다. `Ran 63 tests`뿐 아니라 `OK`와 건너뜀 여부를 함께 확인하세요. 실제 샘플 테스트 시 해당 입력 폴더에는 그 샘플만 있어야 합니다.

### 5. V-World 직접 검증

Windows 로컬 환경에서 다음 명령을 실행합니다. 기존 `verify_vworld.bat`과 같은 Python 모듈을 직접 실행하는 명령입니다.

```powershell
& '.\.venv\Scripts\python.exe' -m gps_analyzer.vworld --config '.\config.json' --output '.\output\vworld_연동검증.json'
Get-Content -LiteralPath '.\output\vworld_연동검증.json' -Encoding UTF8
```

종료 코드0과 `query_verified=true`, `schema_ready=true`를 확인합니다. 코드2는 키 없음·빈 검색·속성 매핑 미완료·인증 제한 등으로 아직 실조회/스키마 확인을 완료하지 못했다는 뜻입니다. `status`와 `schema_issues`를 확인하세요. 등록된 서비스 URL은 `http://localhost:8000`을 유지하며 인증 헤더 위조나 클라우드 우회를 하지 않습니다. 불투명한 속성 이름은 README의 V-World 설명에 따라 공식 스키마와 대조하여 명시적으로 매핑합니다.

API를 실제 일반 분석에 적용하려면 검증 후 메모장으로 `config.json`의 `api.enabled`를 `true`로 변경하세요. GPS만 분석하려면 `false`를 유지합니다.

```powershell
notepad.exe '.\config.json'
```

### 6. 전체 GPS 원본 폴더 분석

원본 21대·5개월 Excel을 프로그램 폴더 밖의 전용 폴더에 넣습니다. 예시 `D:\GPS원본`을 실제 경로로 바꾸세요. 입력과 출력 폴더를 같게 지정하지 않습니다. 하위 폴더도 자동 검색하고 파일별로 순차 처리하며 완료된 캐시를 재사용합니다.

```powershell
& '.\.venv\Scripts\python.exe' -m gps_analyzer --input 'D:\GPS원본' --output '.\output' --work '.\work_data' --config '.\config.json'
if ($LASTEXITCODE -ne 0) { throw 'Analysis failed. Check work_data\analysis.log.' }
```

### 7. 최종 Excel과 로그 열기

```powershell
Invoke-Item -LiteralPath '.\output\아산시_21대차량_2026년4월~8월_방문장소_통합분석.xlsx'
Get-Content -LiteralPath '.\output\validation.json' -Encoding UTF8
Get-Content -LiteralPath '.\work_data\analysis.log' -Encoding UTF8 -Tail 50
```

최종 Excel은 7개 기본 시트와 차트를 포함합니다. 보고서는 다음 실행 때 갱신되므로 필요한 이전 결과는 먼저 복사하세요. 누락된 차량/월과 API 조회 상태는 `validation.json`, 마지막 실행 상태는 `work_data/run_status.json`에서 확인합니다. 실행 실패 뒤 남아 있는 Excel은 이전 결과일 수 있습니다.

이번 변경은 실행 문서와 배포 ZIP만 보완한 것으로 GPS 알고리즘·63개 테스트·기존 배치 파일을 변경하지 않습니다. Windows 실기·스마트 앱 컨트롤·실제 API 키 인증·전체 2GB 데이터 처리는 별도 검증 대상입니다.


## 설치와 실행 (Windows)

Python 3.12 64bit를 설치하고 프로젝트 폴더에서 실행합니다. 원본 폴더는 프로젝트 밖의 별도 폴더로 두세요.

```bat
install.bat
run.bat "D:\GPS원본"
```

명령어로 직접 실행할 수도 있습니다.

```bat
.venv\Scripts\python.exe -m gps_analyzer --input "D:\GPS원본" --output output --work work_data --config config.json
```

Linux/macOS:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m gps_analyzer --input /data/gps --output output --work work_data
```

기본값은 `api.enabled=false`입니다. API 키와 GIS 자료가 없어도 전체 분석과 7개 시트 보고서가 생성됩니다. 입력/출력 폴더를 같게 하거나 출력을 입력 아래에 두면 재수집을 방지하기 위해 오류로 종료합니다. 원본에는 읽기만 수행하며 원본 GPS는 납품 ZIP이나 Git에 포함하지 않습니다.

## 산출물

- `output/아산시_21대차량_2026년4월~8월_방문장소_통합분석.xlsx`: 요청한 7개 기본 시트, 필터·정렬·날짜/숫자 서식·2개 차트
- `output/체류후보_검증.xlsx`: 3분 이상 유효 후보 및 핵심통계 제외 구간. 3분 미만뿐 아니라 이동량 과다로 제외한 긴 구간도 검토 가능
- `output/차량월별_원본검증.csv`: 원본·정제 제외·중복·동시각 충돌·최종 정상 건수 및 대사 결과
- `output/input_validation.json`: 파일별 SHA256, 원본 및 정제 사유별 건수
- `output/validation.json`: 검증 결과, 관측 기간, 누락 차량·월, 후보 수, API 호출 수
- `output/source_evidence.jsonl`: 출처별 전체 근거. Excel 셀 한도 32,767자를 넘는 조회 결과는 이 파일에서 확인
- `work_data/analysis.log`, `run_status.json`: 진행 로그 및 실행 성공/실패 상태

장소 순위·월별·차량별·상세·자동 분류·시설 유형별·검토 목록을 모두 생성합니다. 모든 유효 장소를 표에 포함합니다. 차트만 읽기 편하게 각 분할 시트의 첫 30개 행을 표시합니다. 1,048,575개 데이터 행을 초과하면 같은 통합문서 내 시트를 자동 분할합니다. 차량별 시트는 21대 각각에 대해 방문 수와 총 체류시간 열을 포함합니다.

**샘플 결과는 하루·29호차 데이터만으로 산출한 결과입니다.** 다른 차량과 달의 0은 미방문을 증명하지 않으며 미입력일 수 있습니다. 누락 차량·월은 `validation.json`에서 확인하세요. 월별·날짜는 체류 시작시각을 기준으로 집계하며 자정을 넘은 구간을 중복 분할하지 않습니다.

## 입력과 정제

입력 폴더와 하위 폴더의 `.xlsx`, `.xlsm` 파일을 순차 검색합니다. Excel 잠금 파일(`~$`)은 제외합니다. `.xls`는 경고 후 제외하므로, 해당 형식이 있으면 원본을 보존한 별도 `.xlsx` 사본이 필요합니다. 암호화된 파일은 지원하지 않습니다. 읽지 못한 파일/시트는 로그를 남기고 실행을 실패 처리하여 빠진 원본을 정상 완료처럼 보고하지 않습니다. 완료된 입력 캐시는 유지됩니다.

앞 30행에서 GPS수집시간/위도/경도 필수 열과 속도/삭제여부/차량번호 선택 열을 찾습니다. 다른 열 이름은 `config.json`의 `columns`에 `{"time":"운행일시","lat":"위도값","lon":"경도값"}`처럼 지정할 수 있습니다. 차량번호는 `ASAN_29_2026_06_11.xlsx`와 같은 파일명 또는 데이터 차량 열에서 읽고, 서로 다르면 제외합니다. 파일명 날짜는 시각만 있는 셀에 한해서 사용하며, 날짜와 시간이 모두 있는 셀은 실제 데이터를 우선합니다. 숫자 호차 또는 `29호차` 형식의 차량 열을 지원하며 별도 차량등록번호→호차 매핑은 필요 시 전처리해야 합니다.

시간은 Excel datetime 또는 ISO 형식 문자열을 지원합니다. 원본 시각은 한국 현지의 timezone 없는 시각으로 해석하며 임의 변환하지 않습니다. 기본 속도 단위는 km/h입니다. 속도 결측은 삭제하지 않고 품질 경고를 남깁니다. 기본 좌표 범위는 대한민국을 포함하는 경도124~132·위도33~39.5입니다. 범위를 변경할 수 있습니다. 잘못된 시각·좌표(1000,1000 포함)·음수/비정상 속도·삭제 표시·분석 범위 밖 기록은 사유별 집계합니다.

중복 기준은 `차량+시각+위도+경도+속도`입니다. IOT_ID처럼 매번 달라지는 필드는 중복 기준에 사용하지 않습니다. 중복 제거 후 같은 차량·시각에 서로 다른 위치/속도가 있으면 어떤 것이 맞는지 임의 선택하지 않고 해당 시각의 기록을 모두 충돌 제외합니다. 다음 대사가 성립하는지 검사합니다.

```
원본 = 정제 제외 + 중복 제외 + 동시각 충돌 제외 + 최종 정상
```

## 체류 탐지 설정

`config.json`의 주요 항목:

| 설정 | 기본값 | 의미 |
|---|---:|---|
| `min_stop_seconds` | 180 | 핵심통계 최소 체류시간 |
| `radius_m` | 40 | 구간 첫 좌표로부터 허용하는 구면거리 |
| `max_gap_seconds` | 120 | 연속 GPS 사이 최대 간격; 초과 시 구간 종료 |
| `max_stop_speed_kmh` | 5 | 이 속도를 초과한 기록은 체류점으로 사용하지 않음 |
| `max_path_m` | 160 | 구간 내 누적 이동거리 한도; 초과 구간 전체를 검토 대상으로 제외 |
| `jump_speed_kmh` | 150 | 좌표로 계산한 순간 속도가 초과하면 GPS 튐 경고·구간 분리 |
| `building_uncertainty_m` | 15 | 건물 식별 시 최소 위치 불확실성; 체류 좌표 퍼짐도 함께 반영 |
| `batch_rows` | 10000 | DuckDB 결과를 읽는 배치 크기 |
| `duckdb_memory_limit` | 512MB | DuckDB 메모리 한도; 정렬/집계는 디스크 spill 가능 |

고정 첫 좌표 기준으로 판정하여 조금씩 이동하는 점들을 무한히 잇는 현상을 막습니다. 구간 내 각 기록 간격도 검증합니다. 긴 공백은 새 좌표 시각이 아니라 **이전 GPS 시각에서 종료**합니다. 이동 속도, GPS 튐, 누적 경로를 추가 점검하며 교통정체 여부를 GPS만으로 확정하지 않습니다. 누적 경로 한도 초과는 한 정차를 여러 방문으로 쪼개지 않고 구간 전체를 제외합니다. 이 보수적인 기준은 GPS 흔들림이 심한 실제 체류를 누락할 수 있으므로 제외 구간을 함께 제공합니다.

대표 좌표는 구간 평균 좌표에 가장 가까운 실제 관측 좌표입니다. 긴 체류 좌표는 1MB를 넘으면 디스크 임시 파일로 넘기고 종료 시 순회하여 대표점을 구합니다. 원본 파일은 openpyxl read-only로 순차 읽고 Parquet로 저장하며, 전체 GPS를 pandas DataFrame이나 리스트로 모으지 않습니다. Excel shared-string 테이블과 GIS 건물 레이어, 고유 장소 메타데이터에는 별도 메모리가 필요합니다. GIS는 분석 지역을 잘라 사용하는 것이 좋습니다.

## 공공 건물정보 우선 연계

### 1. GIS건물통합정보

국토교통부 GIS건물통합정보를 공공데이터포털(<https://www.data.go.kr/>) 또는 VWorld(<https://www.vworld.kr/>) 등 해당 자료의 공식 배포처에서 확보합니다. 제공 형식과 필드가 배포본마다 다르므로, **건물 폴리곤을 WGS84(EPSG:4326) GeoJSON으로 변환한 지역 추출본**을 사용합니다. SHP를 그대로 읽는 기능이나 공공 GIS 다운로드 자동화는 포함하지 않았습니다. QGIS에서 원본 CRS를 정확히 설정한 뒤 WGS84로 내보낼 수 있습니다. `.prj`를 무시하고 좌표를 경위도로 간주해서는 안 됩니다.

설정 예:

```json
"gis_file": "data/asan_buildings.geojson",
"gis_properties": {
  "id": "실제_건물고유번호_필드",
  "name": "실제_건물명_필드",
  "use": "실제_용도명_필드",
  "address": "실제_지번주소_필드",
  "road_address": "실제_도로명주소_필드",
  "pnu": "실제_PNU_필드",
  "registry_id": "실제_대장관리번호_필드",
  "sigunguCd": "sigunguCd", "bjdongCd": "bjdongCd",
  "platGbCd": "platGbCd", "bun": "bun", "ji": "ji"
}
```

누락된 선택 속성은 빈 값이 됩니다. 건물 ID는 필수이며 PNU처럼 여러 건물에 공유될 수 있는 필지를 건물 ID로 사용하지 않습니다. 같은 건물이 여러 피처이면 건물 ID별 dissolve 후 MultiPolygon으로 변환해야 합니다. 기본 필드명은 `building_id,name,use,address,road_address,pnu,mgmBldrgstPk` 등입니다. 용도는 한글 명칭을 사용하며, 숫자 코드만 있다면 공식 코드표와 대조해 명칭 필드를 추가하세요. 자료 버전·라이선스는 `gis_source`에 기록하세요.

단일 건물 폴리곤 안에 대표 좌표가 있고 위치 불확실성 범위 내 경쟁 건물이 없을 때만 건물 ID로 통합합니다. 불확실성 반경은 `max(building_uncertainty_m, 2×구간 최대 반경)`으로 보수적으로 적용합니다. 인접 건물이 여러 개면 분리·검토하며, 폴리곤 밖에서 가까운 건물은 **인근 체류 추정**으로만 표시합니다. 단독/다가구/다세대 등은 확인 가능한 명시적 용도가 있을 때만 분류합니다. `공동주택`이라는 말만으로 아파트로 확정하지 않습니다.

GIS가 없으면 일곱 자리로 표현한 정확히 동일한 GPS 좌표만 같은 미확인 공간 지점으로 취급합니다. 수 m 떨어진 좌표는 자동 합치지 않습니다. 이때 장소 ID는 실제 건물을 확정한 ID가 아닙니다. 같은 실제 장소가 여러 ID로 남을 수 있으므로 GIS 또는 수동 근거를 추가해 검토·통합해야 합니다.

### 2. 건축물대장정보 API

GIS로 식별한 건물의 용도가 불명확하고 PNU 또는 지번 조회 필드가 있을 때 `국토교통부 건축물대장정보 서비스 / getBrTitleInfo`로 추가 확인합니다. 원본 GPS마다 호출하지 않습니다. 동일 지번에 여러 표제부가 있으면 GIS의 `registry_id`와 일치하는 관리번호가 있거나 단일 표제부일 때만 사용합니다. 전체 페이지를 조회하지 못하면 확인으로 사용하지 않습니다. 용도는 `etcPurps`, `mainPurpsCdNm`에서 분류하며, 일반적 건물 용도만으로 세부 유형을 추측하지 않습니다.

`api.verify_known_use=true`를 추가하면 이미 GIS 용도를 아는 건물도 대장으로 교차 검증합니다(기본 false: 호출 절약). 두 용도가 다르면 확정을 보류하고 미확인·검토로 기록합니다. 공공 API가 실패해도 GPS 후보를 삭제하지 않습니다.

### 3. 카카오 Local REST API

`.env.example`을 `.env`로 복사하고 키를 설정한 다음 `config.json`의 `api.enabled`를 true로 바꿉니다. `.env` 파일은 Git 제외 대상입니다.

```dotenv
KAKAO_REST_API_KEY=발급받은_REST_API_키
DATA_GO_KR_SERVICE_KEY=건축물대장정보_활용승인_서비스키
```

공공자료에 이름/주소가 충분하면 카카오를 생략합니다. 필요한 고유 장소에 대해 좌표→주소, 주변 병원(HP8)·약국(PM9)·복지관 키워드를 조회합니다. 주변 검색 첫 페이지(각 15개 이내)는 참고 후보이며 전수 시설 목록이 아닙니다. 가장 가까운 시설을 실제 방문 시설로 확정하지 않습니다. 카카오 주소 건물명은 `좌표 기반 추정`으로 표시하고, 주변 POI가 있다는 사실만으로 건물 유형을 바꾸지 않습니다.

출처별 장소명·용도·주소·조회 상태·근거를 Excel 자동 분류 시트의 조회 결과/정보원 비교에 기록합니다. 주소가 다르면 표기 차이를 포함해 검토 대상으로 표시합니다. 신뢰도 0.1/0.35/0.7/0.85/1.0 등은 규칙상 수준이며 검증된 확률이 아닙니다. 수동 확인값은 1.0으로 표시하지만 GPS 품질과 과거 출처 충돌 경고는 유지합니다.

### API 제한·캐시·저장 조건

요청 제한은 기본 300회/실행, 호출 간격 0.3초, 타임아웃 10초, 재시도 2회입니다. 제한은 실패/재시도를 포함합니다. 429·5xx·네트워크 오류를 재시도하고 4xx/응답 오류는 미확인 상태로 남깁니다. 실패 결과는 성공 캐시로 저장하지 않으며 재실행 시 재조회할 수 있습니다. 건축물대장 캐시는 기본 24시간, 카카오는 실행 중 메모리 캐시만 기본 사용합니다. API별 실패는 격리됩니다.

카카오 디스크 **요청 캐시**는 기본 꺼져 있습니다. `kakao_persistent_cache=true`와 허용된 `cache_ttl_hours`를 함께 지정해야 켜지며 만료 항목은 다음 실행 때 삭제합니다. 이 설정과 별개로 **생성한 Excel/출처 근거/장소 DB에는 조회 결과가 들어갑니다.** API별 최신 약관과 활용승인에서 허용하는 저장 항목·기간을 확인한 후 API를 켜고, 보고서/백업/장소 DB를 포함한 보관·삭제 정책을 적용해야 합니다. 본 프로그램이 약관상 보관 권한을 부여하거나 보고서의 보관기한을 자동 집행하지는 않습니다. 이번 납품은 키 없는 실행이므로 외부 조회·API 데이터 저장은 없습니다. 실 API의 승인·응답 스키마·약관은 키와 실제 자료 확보 후 별도 확인 대상입니다.

## 장소 수정과 안정적 ID

`place_overrides.csv`에 보고서의 `place_id`와 수정할 `name,major,minor,address,road_address`를 기입하세요. UTF-8 CSV를 사용합니다. CSV에서 비어 있는 열은 기존 값을 지우지 않습니다. 명시적으로 같은 장소를 통합하려면 `canonical_place_id`에 남길 장소 ID를 입력합니다. 단순히 이름을 같게 바꾸는 것으로 합쳐지지 않습니다.

수동 수정값은 `work_data/places.sqlite`에도 보존되며 CSV가 없어져도 유지합니다. 새 GIS로 기존 수동 ID 두 개가 같은 건물에 연결되어도 자동으로 한쪽 ID를 없애지 않고 충돌로 검토합니다. CSV와 `places.sqlite`를 함께 백업하세요. 작업 폴더를 삭제하면 이력/수동값/ID 연결도 사라집니다. 최초 ID는 데이터 근거의 해시로 결정하며 같은 입력·근거의 재실행은 동일한 ID를 냅니다. 건물 근거가 없는 새 좌표를 기존 장소로 추측하여 연결하지 않습니다.

## 중단 후 재개와 대용량 처리

각 입력 파일은 내용 SHA256·경로·정제 설정별 Parquet와 완료 메타데이터를 원자적으로 저장합니다. 재실행 시 파일 해시 확인은 하지만 완료 Excel은 다시 파싱하지 않습니다. 이동/변경/정제 설정 변경은 해당 캐시를 새로 생성합니다. 차량별 체류 결과도 정상 GPS 지문과 탐지 설정별로 저장하므로 변경 없는 차량은 재탐지하지 않습니다. 중단된 입력 파일/차량은 해당 단위부터 다시 처리합니다. 현재 입력 폴더에서 빠진 파일의 옛 캐시는 통계에 섞이지 않습니다.

Ctrl+C 후 같은 명령으로 재실행하세요. 같은 작업 폴더의 동시 실행은 OS 잠금으로 차단합니다. DuckDB는 512MB 기본 제한 아래 디스크 임시 정렬을 사용합니다. 원본 외에 Parquet·DuckDB·정렬용 추가 디스크가 필요하며 실제 자료 크기에 맞춰 여유 공간을 확보하세요. 완료하지 않은 출력 Excel 임시 파일을 최종 결과로 바꾸지 않습니다. 최종 성공 여부는 `run_status.json`과 `validation.json`을 기준으로 확인하세요. 실패 시 기존 완료 보고서는 이전 실행 결과일 수 있습니다.

## 테스트

```bat
test.bat
```

실제 샘플까지 검증하려면 다음과 같이 실행합니다. 원본은 프로젝트에 복사하거나 Git에 넣을 필요가 없습니다.

```bat
set "GPS_SAMPLE_FILE=D:\GPS샘플\ASAN_29_2026_06_11.xlsx"
test.bat
```

`GPS_SAMPLE_FILE`이 없으면 실제 샘플 테스트만 명시적으로 건너뜁니다. 실제 샘플 테스트 시 해당 폴더에는 그 샘플 하나만 두세요. 기본 단위/통합 테스트는 합성 데이터로 항상 실행합니다.

검증 범위: 180초 경계, 120초 공백 경계, 긴 공백 제외, 고정 반경과 이동/속도/GPS 튐, 누적 흔들림에 따른 잘못된 방문 분할 방지, 긴 체류의 디스크 spill, 중복·동시각 충돌, API 실패/제한/캐시, 인접 건물 분리, 같은 건물의 차량 공통 ID, 수동 ID 유지, 자료 변경 후 보존, 전체 합계 대사, 보고서 분할과 문자열 수식 방지. 실제 샘플에서는 각 후보의 모든 GPS 시각·좌표·속도·기록 수·체류시간을 원본과 대조하고, 원본 해시가 바뀌지 않았는지 검사합니다.

현재 실증 범위는 제공된 하루 샘플과 합성 테스트입니다. 21대·5개월·2GB 이상의 실제 전체 처리, Windows 실기 실행, 실제 GIS 배포본 및 유효 키로 하는 API 호출은 아직 검증하지 않았습니다. 이를 완료한 것으로 보고하지 않습니다.

## V-World GIS건물통합정보 온라인 연동 (추가)

### 기존 인증키와 실행 위치

발급받은 키는 `.env`의 `VWORLD_API_KEY`에서만 읽습니다. 등록된 서비스 URL은 그대로 유지합니다.

```dotenv
VWORLD_API_KEY=발급받은_브이월드_키
VWORLD_SERVICE_URL=http://localhost:8000
```

`http://localhost:8000` 등록 키는 기본적으로 **Windows의 로컬 Python 실행에서만** 조회하도록 제한했습니다. 클라우드나 WSL/Linux에서 localhost 등록을 가장하여 요청하지 않습니다. `Referer`·`Origin` 헤더를 만들어 넣지 않으며, 인증 실패 후 다른 엔드포인트나 키로 우회하지 않습니다. 이 프로그램은 웹 서버나 대시보드를 만들지 않습니다. URL은 공식 요청의 `domain` 파라미터에 등록값 그대로 전달하며, 이 값만으로 인증 성공이 보장되지는 않습니다.

선택한 **2D데이터 API**의 `GetFeature`를 사용하므로 WMS 지도 이미지를 분석할 필요가 없습니다. WFS·검색 API를 추가로 호출하지 않습니다. 요청 대상은 `https://api.vworld.kr/req/data`, 기본 레이어는 `LT_C_BLDGINFO`, 요청 좌표계는 `EPSG:4326`입니다. 공식 서비스 목록은 [공공데이터포털 국토교통부 GIS건물통합정보(WMS/WFS)](https://www.data.go.kr/data/15123970/openapi.do), API 설정과 최신 가이드는 [V-World](https://www.vworld.kr/)에서 확인하세요. 서비스가 공개되어 있다는 사실과 본인 키가 실제로 해당 레이어에 접근할 수 있다는 사실은 별개입니다.

### 첫 단계: Windows에서 실제 응답 검증

프로젝트 폴더에서 설치 후 아래를 실행합니다. 별도 키 입력 인자를 만들지 않아 명령 이력에 키가 남지 않습니다.

```bat
verify_vworld.bat
```

기본 검증 좌표는 제공된 실제 샘플의 첫 체류 위치(위도36.7782377, 경도127.0086517)입니다. 다른 위치도 지정할 수 있습니다.

```bat
verify_vworld.bat --lat 36.7782377 --lon 127.0086517
```

이 명령은 일반 분석의 `api.enabled=false` 상태에서도 **V-World 검증만** 실행하며 카카오나 건축물대장을 호출하지 않습니다. 오래된 캐시를 인증 성공으로 오인하지 않도록 실제 새 요청을 사용합니다. 결과는 `output/vworld_연동검증.json`에 기록합니다.

- `query_verified`: 실제 요청에서 피처를 받았는지
- `geometry_verified`: 경위도 축·좌표계·유효 Polygon/MultiPolygon·건물 ID를 확인했는지
- `use_field_verified`, `schema_ready`: 명시적으로 매핑된 용도명 필드를 확인했는지
- `property_names`, `mapped_fields`: **실제로 반환된** 속성명과 사용한 매핑
- `sample_features`: 실제 반환 피처 최대3개(키는 제거)
- `status`, `schema_issues`: 인증/도메인/HTTP/빈 결과/속성/페이지 잘림 등의 상태

`query_verified=true`와 `schema_ready=true`일 때만 종료 코드0입니다. 키 없음·인증 제한·속성 매핑 미완료·빈 검색은 코드2로 종료합니다. 빈 검색은 곧 인증 실패라는 의미가 아니며, 건물 스키마를 검증하지 못했다는 뜻입니다. JSON의 `missing_key`는 키 미설정, `local_windows_required`는 클라우드 실행 제한, `authentication_or_domain_error`/`http_401`/`http_403`은 인증·도메인 확인이 필요하다는 뜻입니다. 실제 실패 응답을 받으면 등록 URL과 해당 API의 활용승인을 공식 설정에서 확인하세요. URL 변경·헤더 위조·다른 서비스로의 우회를 자동 수행하지 않습니다.

### 반환 속성과 용도 분류

서버 응답의 필드명을 추측해 `a9` 등을 무조건 용도로 읽지 않습니다. 알려진 명시적 용도명(`main_prpos_cd_nm`, `main_prpos_code_nm`, `mainPrposCodeNm`, `main_purps_cd_nm`, `건축물용도명`)이 실제 존재하면 그 값을 읽습니다. 건물 ID는 명시적 GIS 건물 ID 또는 응답 피처ID를 사용하며, 같은 필지에 여러 동이 있을 수 있어 PNU로 건물을 합치지 않습니다.

서버가 `a0/a1/a8/a9`처럼 불투명한 속성을 반환하면 검증 JSON의 값과 **그 레이어의 공식 속성 설명**을 대조한 뒤 `config.json`의 `vworld.properties`에 명시적으로 지정하세요. 예를 들어 실제 설명에서 a1=건물통합식별번호, a9=용도명, a8=용도코드임을 확인한 경우에만 다음처럼 설정합니다. 이 예시는 현재 사용자의 실서버 반환 스키마를 확인했다는 의미가 아닙니다.

```json
"properties": {
  "id": "a1",
  "use": "a9",
  "use_code": "a8"
}
```

그 후 `verify_vworld.bat`를 다시 실행해 `mapped_fields`와 샘플 값을 확인합니다. 이름·주소·PNU·대장관리번호도 `name,address,road_address,pnu,registry_id` 항목으로 실제 속성명을 지정할 수 있습니다. 용도 코드만 있고 명칭이 없으면 임의 코드표를 적용하지 않고 미확인으로 남깁니다.

아파트·단독주택·다가구주택·다세대주택·연립주택이라는 구체적인 용도명이 있고 단일 건물 도형을 식별한 경우에 해당 유형으로 분류합니다. `공동주택`만으로 아파트, `단독주택`만으로 다가구를 추정하지 않습니다. 모순된 복수 유형, 인접 건물 혼동, 미매핑 필드, 잘린 페이지, 불완전한 경쟁 건물 도형은 확정 분류에 사용하지 않습니다. 건물의 식별과 실제 차량의 시설 이용 여부는 계속 구분합니다.

### 검증 이후 일반 분석에 적용

`config.json`의 `api.enabled`를 true로 설정하면 정상 체류 후보를 대상으로 V-World가 적용됩니다. `vworld.enabled` 기본값은 true이지만, 전체 외부 조회 스위치가 false이면 실제 요청은 하지 않습니다. 완전한 지역 GIS 자료가 이미 있으면 그 자료를 먼저 사용하고 V-World를 생략합니다. 로컬 GIS에서 인접 건물이 모호하면 외부 결과 하나를 가져와 그 모호성을 임의로 무시하지 않습니다. 공공 건물 ID가 동일할 때만 두 GIS의 속성을 보완합니다.

V-World 도형과 주용도로 건물을 식별하고 필요한 경우 카카오로 주소/장소명 후보를 보완합니다. 카카오 주변 약국·병원 등이 검색되었다는 이유로 아파트의 건물 유형을 바꾸거나 실제 방문 장소로 확정하지 않습니다. 불명확한 용도는 가능한 경우 기존 건축물대장 경로로 추가 검증합니다.

기존 7개 시트는 그대로 유지하며 `장소 자동 분류`에 **V-World 조회 결과** 열을 추가했습니다. 건물 유형은 기존 대분류/세부 분류에, 판단은 분류 근거/정보 출처/신뢰도/정보원 비교에 기록합니다. 검토 사유에도 V-World 인증·속성 문제를 남깁니다. `validation.json`의 `sources.vworld_status`는 V-World 상태이며 GPS 분석의 성공 여부와 별개입니다.

요청은 같은 작은 지역 타일끼리 재사용하고, 기존 API 호출량 제한·타임아웃·재시도·공공 캐시 만료 설정을 공유합니다. 페이지를 모두 읽어 인접 건물을 확인하며, 최대 페이지 제한에 걸리면 확정하지 않습니다. 인증 실패는 성공 캐시에 넣지 않고 해당 실행에서 추가 장소에 반복 요청하지 않습니다. 다른 API·체류 기록·Excel 출력은 계속 진행하며 다음 실행에서 다시 검증할 수 있습니다. 공공자료와 생성된 보고서의 보관은 해당 서비스의 허용 범위·기간을 따라야 합니다.

이번 클라우드 환경에는 V-World 키가 없으므로 실제 건물 속성과 계정별 인증은 아직 검증하지 않았습니다. 모의 응답 테스트를 실API 연동 성공으로 보고하지 않습니다.
